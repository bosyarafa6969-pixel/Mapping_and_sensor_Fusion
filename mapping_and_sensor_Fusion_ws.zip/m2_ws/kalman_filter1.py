#!/usr/bin/env python3

from collections import deque
import numpy as np
import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TwistStamped, TwistWithCovarianceStamped

SPEED_TYPES = {
    "Odometry": Odometry,
    "TwistStamped": TwistStamped,
    "TwistWithCovarianceStamped": TwistWithCovarianceStamped,
}


def stamp_to_sec(stamp):
    return stamp.sec + stamp.nanosec * 1e-9


def quat_to_rot(q):
    """geometry_msgs Quaternion -> 3x3 rotation matrix."""
    x, y, z, w = q.x, q.y, q.z, q.w
    n = x * x + y * y + z * z + w * w
    if n < 1e-12:
        return np.eye(3)
    s = 2.0 / n
    return np.array([
        [1 - s * (y * y + z * z), s * (x * y - z * w), s * (x * z + y * w)],
        [s * (x * y + z * w), 1 - s * (x * x + z * z), s * (y * z - x * w)],
        [s * (x * z - y * w), s * (y * z + x * w), 1 - s * (x * x + y * y)],
    ])

class KalmanFilter3D:

    def __init__(self, pose_measurement_var, speed_measurement_var, accel_process_noise):
        self.n = 6
        self.sigma_a2 = accel_process_noise ** 2

        # Measurement matrices: one per sensor
        self.H_pose = np.hstack([np.eye(3), np.zeros((3, 3))])    # selects p
        self.H_speed = np.hstack([np.zeros((3, 3)), np.eye(3)])   # selects v

        # Measurement noise: one per sensor
        self.R_pose = np.eye(3) * pose_measurement_var
        self.R_speed = np.eye(3) * speed_measurement_var

    def build_A(self, dt):
        A = np.eye(6)
        A[0:3, 3:6] = np.eye(3) * dt
        return A

    def build_Q(self, dt):
        q = self.sigma_a2
        Qb = q * np.array([[dt ** 4 / 4.0, dt ** 3 / 2.0],
                           [dt ** 3 / 2.0, dt ** 2]])
        return np.kron(Qb, np.eye(3))

    def predict(self, X_past, P_past, dt):
        A = self.build_A(dt)
        Q = self.build_Q(dt)
        X_pred = A @ X_past                      
        P_pred = A @ P_past @ A.T + Q
        return X_pred, P_pred

    def correct(self, X_pred, P_pred, Z, H, R):
        Y = Z - H @ X_pred                       # innovation residual
        S = H @ P_pred @ H.T + R                 # innovation covariance
        K = P_pred @ H.T @ np.linalg.inv(S)      # Kalman gain
        X_upd = X_pred + K @ Y
        P_upd = (np.eye(self.n) - K @ H) @ P_pred
        P_upd = 0.5 * (P_upd + P_upd.T)          
        return X_upd, P_upd

#  ROS 2 node

class KalmanFilterNode(Node):
    def __init__(self):
        super().__init__("kalman_filter")

        self.declare_parameter("kiss_topic", "/kiss/odometry")
        self.declare_parameter("speed_topic", "/speedometer_readings")
        self.declare_parameter("speed_msg_type", "Odometry")
        self.declare_parameter("sigma_pose", 0.30)
        self.declare_parameter("sigma_speed", 0.10)    
        self.declare_parameter("sigma_accel", 0.50)    
        self.declare_parameter("max_dt", 2.0)          
        self.declare_parameter("speed_in_body_frame", False)
        self.declare_parameter("sync_by_stamp", True)

        p = self.get_parameter
        speed_type_name = p("speed_msg_type").value
        if speed_type_name not in SPEED_TYPES:
            raise ValueError(f"speed_msg_type must be one of {list(SPEED_TYPES)}")
        self.speed_type_name = speed_type_name
        self.max_dt = float(p("max_dt").value)
        self.body_frame = bool(p("speed_in_body_frame").value)
        self.sync = bool(p("sync_by_stamp").value)

        self.kf = KalmanFilter3D(
            pose_measurement_var=float(p("sigma_pose").value) ** 2,
            speed_measurement_var=float(p("sigma_speed").value) ** 2,
            accel_process_noise=float(p("sigma_accel").value),
        )

        self.X = np.zeros(6)
        self.P = np.eye(6)
        self.t = None
        self.initialized = False
        self.speed_queue = deque()
        self.R_world_body = np.eye(3)
        self.last_orientation = None
        self.frame_id = "odom"
        self.child_frame_id = "base_link"

        self.pub = self.create_publisher(Odometry, "filtered_pose", 100)
        self.create_subscription(Odometry, p("kiss_topic").value, self.kiss_cb, 100)
        self.create_subscription(
            SPEED_TYPES[speed_type_name], p("speed_topic").value, self.speed_cb, 100)
        self.get_logger().info(
            f"KF ready: pose<-{p('kiss_topic').value}, "
            f"speed<-{p('speed_topic').value} ({speed_type_name})")

    def do_predict(self, t):
        if self.t is None:
            self.t = t
            return
        dt = t - self.t
        if dt <= 0.0:   
            return
        if dt > self.max_dt:
            self.get_logger().warn(
                f"dt={dt:.3f}s clamped to {self.max_dt}s (check bag timestamps)")
            dt = self.max_dt
        self.X, self.P = self.kf.predict(self.X, self.P, dt)
        self.t = t

    def do_correct(self, Z, H, R):
        self.X, self.P = self.kf.correct(self.X, self.P, Z, H, R)

    def kiss_cb(self, msg):
        t = stamp_to_sec(msg.header.stamp)
        pos = msg.pose.pose.position
        Z = np.array([pos.x, pos.y, pos.z])
        self.frame_id = msg.header.frame_id or self.frame_id
        self.child_frame_id = msg.child_frame_id or self.child_frame_id
        self.last_orientation = msg.pose.pose.orientation
        self.R_world_body = quat_to_rot(self.last_orientation)

        if not self.initialized:
            self.X[0:3] = Z
            self.P = np.diag([self.kf.R_pose[0, 0]] * 3 + [1.0] * 3)
            self.t = t
            self.initialized = True
            self.publish(msg.header.stamp)
            return

        self.flush_speed_queue(t)
        self.do_predict(t)
        self.do_correct(Z, self.kf.H_pose, self.kf.R_pose)
        self.publish(msg.header.stamp)

    def speed_cb(self, msg):
        if not self.initialized:
            return
        if self.speed_type_name == "TwistStamped":
            lin = msg.twist.linear
        else: 
            lin = msg.twist.twist.linear
        v = np.array([lin.x, lin.y, lin.z])
        stamp = msg.header.stamp
        t = stamp_to_sec(stamp)

        if self.sync and t > self.t + 1e-9:
            self.speed_queue.append((t, v, stamp))
            return
        self.apply_speed(t, v, stamp)

    def flush_speed_queue(self, t_limit):
        while self.speed_queue and self.speed_queue[0][0] <= t_limit:
            t, v, stamp = self.speed_queue.popleft()
            self.apply_speed(t, v, stamp)

    def apply_speed(self, t, v, stamp):
        if self.body_frame:
            v = self.R_world_body @ v
        self.do_predict(t)
        self.do_correct(v, self.kf.H_speed, self.kf.R_speed)
        self.publish(stamp)

    def publish(self, stamp):
        out = Odometry()
        out.header.stamp = stamp
        out.header.frame_id = self.frame_id
        out.child_frame_id = self.child_frame_id
        out.pose.pose.position.x = float(self.X[0])
        out.pose.pose.position.y = float(self.X[1])
        out.pose.pose.position.z = float(self.X[2])
        if self.last_orientation is not None:
            out.pose.pose.orientation = self.last_orientation
        else:
            out.pose.pose.orientation.w = 1.0
        out.twist.twist.linear.x = float(self.X[3])
        out.twist.twist.linear.y = float(self.X[4])
        out.twist.twist.linear.z = float(self.X[5])

        pc, tc = np.zeros(36), np.zeros(36)
        for i in range(3):
            for j in range(3):
                pc[i * 6 + j] = self.P[i, j]
                tc[i * 6 + j] = self.P[3 + i, 3 + j]
        out.pose.covariance = pc.tolist()
        out.twist.covariance = tc.tolist()
        self.pub.publish(out)

def main():
    rclpy.init()
    node = KalmanFilterNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
